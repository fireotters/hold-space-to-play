Hold Space To Play
Developed by benchi99 and CrossfireCam
https://itch.io/profile/benchi99
https://itch.io/profile/crossfirecam


How To Play
------------------
Launch 'holdspace.exe'. Choose your resolution and other settings here.
The game launches with only one control scheme supported: the space bar.
Tap space rapidly to select an option, and hold space to activate that option. If you wish to cancel an action, continue holding for 5 seconds until the action cancels.

To uninstall this game, delete the entire 'Hold Space To Play' folder.


Attributions
------------------
Thanks to Unity Technologies for their Animated Tiles script, provided with the 2d-extras package found here: https://github.com/Unity-Technologies/2d-extras
Thanks to '04' on dafont.com for their '04b_30' font. https://www.dafont.com/04b-30.font
Thanks to 'Codeman38' on dafont.com for their 'Press Start 2P' font. https://www.dafont.com/press-start-2p.font


Sound Attributions
------------------
Universal Sound FX
8BIT_RETRO_Coin_Collect_Two_Note_Twinkle_mono
PUZZLE_Success_Xylophone_2_Two_Note_Climb_Bright_Delay_stereo

Freesounds.org
https://freesound.org/people/Areti18/sounds/394944/
https://freesound.org/people/akelley6/sounds/453050/

Ultimate Game Music Collection
ORBIT LOOP, Learning LOOP, Loneliness Minimal LOOP, Sneaky LOOP